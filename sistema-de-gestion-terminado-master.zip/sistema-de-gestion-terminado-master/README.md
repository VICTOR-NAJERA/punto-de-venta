# sistema-de-gestion-terminado
Sistema de Gestión desarrollado en C#. NET y SQL Server.
