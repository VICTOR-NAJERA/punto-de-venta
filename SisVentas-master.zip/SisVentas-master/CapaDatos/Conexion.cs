﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    class Conexion
    {


        public static string Cn = "Data Source=DAVID-PC; Initial Catalog=DBVentas; Integrated Security=true";
    }
}
