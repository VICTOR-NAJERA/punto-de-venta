# rutacritica
c# y sql server
